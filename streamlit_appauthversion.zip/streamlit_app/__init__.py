"""Streamlit application package initializer."""
